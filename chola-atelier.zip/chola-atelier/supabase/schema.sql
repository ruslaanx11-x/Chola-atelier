-- ============================================================
-- CHOLA ATELIER — CLOUD DATABASE SCHEMA (Supabase / Postgres)
-- Run this in Supabase SQL editor once, on a fresh project.
-- ============================================================

create extension if not exists "uuid-ossp";

-- ---------- CATEGORIES ----------
create table categories (
  id uuid primary key default uuid_generate_v4(),
  name text not null,
  slug text unique not null,
  parent_id uuid references categories(id), -- null = top-level category, else subcategory
  sort_order int default 0,
  created_at timestamptz default now()
);

-- ---------- COLLECTIONS (e.g. "Festive Edit") ----------
create table collections (
  id uuid primary key default uuid_generate_v4(),
  name text not null,
  slug text unique not null,
  description text,
  banner_image text,
  is_active boolean default true,
  created_at timestamptz default now()
);

-- ---------- PRODUCTS ----------
create table products (
  id uuid primary key default uuid_generate_v4(),
  name text not null,
  slug text unique not null,
  description text,
  category_id uuid references categories(id),
  collection_id uuid references collections(id),
  product_type text, -- e.g. "kurta", "earrings"
  price numeric(10,2) not null,
  sale_price numeric(10,2),
  material text,
  sku_prefix text,
  is_featured boolean default false,
  is_new_arrival boolean default false,
  is_best_seller boolean default false,
  is_on_sale boolean default false,
  rating numeric(2,1) default 0,
  review_count int default 0,
  created_at timestamptz default now(),
  updated_at timestamptz default now()
);
create index on products (category_id);
create index on products (collection_id);
create index on products (slug);

-- ---------- PRODUCT VARIANTS (colour x size) ----------
create table product_variants (
  id uuid primary key default uuid_generate_v4(),
  product_id uuid references products(id) on delete cascade,
  colour text,
  colour_hex text,
  size text,
  sku text unique,
  stock int default 0,
  price_override numeric(10,2), -- optional, else use product price
  created_at timestamptz default now()
);
create index on product_variants (product_id);

-- ---------- PRODUCT MEDIA (multi-shot images + video clip) ----------
create table product_media (
  id uuid primary key default uuid_generate_v4(),
  product_id uuid references products(id) on delete cascade,
  media_type text check (media_type in ('image', 'video')) default 'image',
  url text not null,        -- Supabase Storage public URL
  sort_order int default 0, -- controls gallery order; first image = main shot
  created_at timestamptz default now()
);
create index on product_media (product_id);

-- ---------- CUSTOMERS (extends Supabase auth.users) ----------
create table customers (
  id uuid primary key references auth.users(id) on delete cascade,
  full_name text,
  phone text,
  is_admin boolean default false, -- set manually to true in Supabase table editor for store owner/staff accounts
  created_at timestamptz default now()
);

-- ---------- ADDRESSES ----------
create table addresses (
  id uuid primary key default uuid_generate_v4(),
  customer_id uuid references customers(id) on delete cascade,
  label text default 'home', -- home / work / other
  full_name text not null,
  phone text not null,
  line1 text not null,
  line2 text,
  city text not null,
  state text not null,
  pincode text not null,
  is_default boolean default false,
  created_at timestamptz default now()
);

-- ---------- CART (server-synced for logged-in users) ----------
create table cart_items (
  id uuid primary key default uuid_generate_v4(),
  customer_id uuid references customers(id) on delete cascade,
  variant_id uuid references product_variants(id),
  quantity int not null default 1,
  created_at timestamptz default now(),
  unique (customer_id, variant_id)
);

-- ---------- WISHLIST ----------
create table wishlist_items (
  id uuid primary key default uuid_generate_v4(),
  customer_id uuid references customers(id) on delete cascade,
  product_id uuid references products(id) on delete cascade,
  created_at timestamptz default now(),
  unique (customer_id, product_id)
);

-- ---------- COUPONS ----------
create table coupons (
  id uuid primary key default uuid_generate_v4(),
  code text unique not null,
  description text,
  discount_type text check (discount_type in ('flat', 'percent')) not null,
  discount_value numeric(10,2) not null,
  min_order_value numeric(10,2) default 0,
  max_uses int,
  used_count int default 0,
  is_active boolean default true,
  expires_at timestamptz
);

-- ---------- ORDERS ----------
create table orders (
  id uuid primary key default uuid_generate_v4(),
  order_number text unique not null, -- e.g. HC-100482
  customer_id uuid references customers(id),
  address_id uuid references addresses(id),
  subtotal numeric(10,2) not null,
  discount numeric(10,2) default 0,
  coupon_id uuid references coupons(id),
  shipping_fee numeric(10,2) default 0,
  total numeric(10,2) not null,
  payment_method text check (payment_method in ('upi', 'card', 'netbanking', 'cod')) not null,
  payment_status text check (payment_status in ('pending', 'paid', 'failed', 'refunded')) default 'pending',
  razorpay_order_id text,
  razorpay_payment_id text,
  order_status text check (order_status in ('placed', 'packed', 'shipped', 'delivered', 'cancelled')) default 'placed',
  tracking_id text,
  courier_name text,
  is_buy_now boolean default false, -- true = direct "Buy now" order, bypassed cart
  created_at timestamptz default now(),
  updated_at timestamptz default now()
);
create index on orders (customer_id);

-- ---------- ORDER ITEMS ----------
create table order_items (
  id uuid primary key default uuid_generate_v4(),
  order_id uuid references orders(id) on delete cascade,
  product_id uuid references products(id),
  variant_id uuid references product_variants(id),
  product_name text not null,   -- snapshot at time of order
  colour text,
  size text,
  quantity int not null,
  price numeric(10,2) not null, -- price at time of order
  sale_price numeric(10,2)
);

-- ---------- REVIEWS ----------
create table reviews (
  id uuid primary key default uuid_generate_v4(),
  product_id uuid references products(id) on delete cascade,
  customer_id uuid references customers(id),
  rating int check (rating between 1 and 5) not null,
  comment text,
  created_at timestamptz default now()
);

-- ---------- STORE SETTINGS (single row) ----------
create table store_settings (
  id int primary key default 1,
  store_name text default 'Chola Atelier',
  free_shipping_min numeric(10,2) default 999,
  cod_enabled boolean default true,
  contact_email text,
  contact_phone text,
  whatsapp_number text
);
insert into store_settings (id) values (1);

-- ============================================================
-- ROW LEVEL SECURITY
-- ============================================================
alter table customers enable row level security;
alter table addresses enable row level security;
alter table cart_items enable row level security;
alter table wishlist_items enable row level security;
alter table orders enable row level security;
alter table order_items enable row level security;
alter table reviews enable row level security;

-- Customers can only see/edit their own row
create policy "own customer row" on customers
  for all using (auth.uid() = id);

create policy "own addresses" on addresses
  for all using (auth.uid() = customer_id);

create policy "own cart" on cart_items
  for all using (auth.uid() = customer_id);

create policy "own wishlist" on wishlist_items
  for all using (auth.uid() = customer_id);

create policy "own orders" on orders
  for select using (auth.uid() = customer_id);
create policy "own orders insert" on orders
  for insert with check (auth.uid() = customer_id);
create policy "own orders update" on orders
  for update using (auth.uid() = customer_id); -- lets a customer's own checkout/payment-verify update their order

create policy "own order items" on order_items
  for select using (
    exists (select 1 from orders where orders.id = order_items.order_id and orders.customer_id = auth.uid())
  );
create policy "own order items insert" on order_items
  for insert with check (
    exists (select 1 from orders where orders.id = order_items.order_id and orders.customer_id = auth.uid())
  );

create policy "read reviews" on reviews for select using (true);
create policy "write own review" on reviews for insert with check (auth.uid() = customer_id);

-- ============================================================
-- TRIGGER: auto-create a customers row the moment someone signs up.
-- This runs with elevated privileges and does NOT depend on the new
-- user having a logged-in session yet (which they don't, if email
-- confirmation is required) — so it's the reliable way to keep every
-- auth.users row matched with a customers row.
-- ============================================================
create or replace function handle_new_user()
returns trigger as $$
begin
  insert into public.customers (id, full_name)
  values (new.id, new.raw_user_meta_data->>'full_name')
  on conflict (id) do nothing;
  return new;
end;
$$ language plpgsql security definer set search_path = public;

create trigger on_auth_user_created
  after insert on auth.users
  for each row execute function handle_new_user();

-- ============================================================
-- ADMIN WRITE POLICIES
-- The tables above only had public SELECT policies — admins had no way
-- to insert/update/delete products, variants, media, or categories from
-- the browser client. These policies allow writes ONLY for accounts
-- flagged is_admin = true in the customers table (set manually in the
-- Supabase table editor, see README).
-- ============================================================
create or replace function is_admin()
returns boolean as $$
  select coalesce((select is_admin from customers where id = auth.uid()), false);
$$ language sql security definer stable;

create policy "admin write products" on products
  for all using (is_admin()) with check (is_admin());

create policy "admin write variants" on product_variants
  for all using (is_admin()) with check (is_admin());

create policy "admin write media" on product_media
  for all using (is_admin()) with check (is_admin());

create policy "admin write categories" on categories
  for all using (is_admin()) with check (is_admin());

create policy "admin write collections" on collections
  for all using (is_admin()) with check (is_admin());

create policy "admin manage coupons" on coupons
  for all using (is_admin()) with check (is_admin());
alter table coupons enable row level security;
create policy "public read active coupons" on coupons
  for select using (is_active = true);

create policy "admin manage all orders" on orders
  for all using (is_admin()) with check (is_admin());
create policy "admin manage order items" on order_items
  for all using (is_admin()) with check (is_admin());

-- Storage: allow admins to upload/replace/delete files in the
-- "product-media" bucket. Create the bucket itself in the Supabase
-- dashboard (Storage → New bucket → name it exactly "product-media",
-- set Public ON) — these policies only govern who can WRITE to it.
create policy "admin upload product media" on storage.objects
  for insert with check (bucket_id = 'product-media' and is_admin());
create policy "admin update product media" on storage.objects
  for update using (bucket_id = 'product-media' and is_admin());
create policy "admin delete product media" on storage.objects
  for delete using (bucket_id = 'product-media' and is_admin());
create policy "public read product media" on storage.objects
  for select using (bucket_id = 'product-media');

-- Products, categories, media, variants, collections are public read (storefront), write via service role only (admin)
alter table products enable row level security;
create policy "public read products" on products for select using (true);

alter table product_variants enable row level security;
create policy "public read variants" on product_variants for select using (true);

alter table product_media enable row level security;
create policy "public read media" on product_media for select using (true);

alter table categories enable row level security;
create policy "public read categories" on categories for select using (true);

alter table collections enable row level security;
create policy "public read collections" on collections for select using (true);

-- ============================================================
-- FUNCTION: decrement stock on order placement (called from API route)
-- ============================================================
create or replace function decrement_variant_stock(p_variant_id uuid, p_qty int)
returns void as $$
begin
  update product_variants
  set stock = stock - p_qty
  where id = p_variant_id and stock >= p_qty;

  if not found then
    raise exception 'Insufficient stock for variant %', p_variant_id;
  end if;
end;
$$ language plpgsql security definer;
