import Link from "next/link";
import { Search, Heart, ShoppingBag } from "lucide-react";

export default function Header() {
  return (
    <header className="flex items-center justify-between px-4 py-3 border-b border-charcoal/10 sticky top-0 bg-cream/95 backdrop-blur z-10 max-w-md">
      <Link href="/" className="font-display text-lg tracking-wide">
        Chola Atelier
      </Link>
      <div className="flex items-center gap-4">
        <Link href="/search" aria-label="Search"><Search size={20} strokeWidth={1.5} /></Link>
        <Link href="/wishlist" aria-label="Wishlist"><Heart size={20} strokeWidth={1.5} /></Link>
        <Link href="/cart" aria-label="Cart"><ShoppingBag size={20} strokeWidth={1.5} /></Link>
      </div>
    </header>
  );
}
