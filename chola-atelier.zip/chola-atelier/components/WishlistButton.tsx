"use client";

import { useEffect, useState } from "react";
import { useRouter } from "next/navigation";
import { Heart } from "lucide-react";
import { createClient } from "@/lib/supabase/client";

export default function WishlistButton({ productId }: { productId: string }) {
  const router = useRouter();
  const [saved, setSaved] = useState(false);
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    const supabase = createClient();
    (async () => {
      const { data: { user } } = await supabase.auth.getUser();
      if (!user) return;
      const { data } = await supabase
        .from("wishlist_items")
        .select("id")
        .eq("customer_id", user.id)
        .eq("product_id", productId)
        .maybeSingle();
      setSaved(!!data);
    })();
  }, [productId]);

  async function toggle() {
    setLoading(true);
    const supabase = createClient();
    const { data: { user } } = await supabase.auth.getUser();
    if (!user) {
      router.push("/login?redirect=/product");
      return;
    }

    if (saved) {
      await supabase.from("wishlist_items").delete().eq("customer_id", user.id).eq("product_id", productId);
      setSaved(false);
    } else {
      await supabase.from("wishlist_items").insert({ customer_id: user.id, product_id: productId });
      setSaved(true);
    }
    setLoading(false);
  }

  return (
    <button onClick={toggle} disabled={loading} aria-label="Toggle wishlist">
      <Heart size={20} strokeWidth={1.5} className={saved ? "fill-rust-600 text-rust-600" : "text-ink"} />
    </button>
  );
}
