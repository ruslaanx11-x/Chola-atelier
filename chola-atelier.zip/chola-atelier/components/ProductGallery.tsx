"use client";

import { useRef, useState } from "react";
import Image from "next/image";
import { PlayCircle } from "lucide-react";
import type { ProductMedia } from "@/lib/types";

const SWIPE_THRESHOLD = 40; // px — how far a swipe must travel to count

export default function ProductGallery({ media }: { media: ProductMedia[] }) {
  const [active, setActive] = useState(0);
  const touchStartX = useRef<number | null>(null);

  if (!media || media.length === 0) {
    return <div className="aspect-[4/5] bg-sand-100 flex items-center justify-center text-charcoal/30">No media</div>;
  }

  const current = media[active];

  function goTo(index: number) {
    setActive(Math.max(0, Math.min(media.length - 1, index)));
  }

  function handleTouchStart(e: React.TouchEvent) {
    touchStartX.current = e.touches[0].clientX;
  }

  function handleTouchEnd(e: React.TouchEvent) {
    if (touchStartX.current === null) return;
    const deltaX = e.changedTouches[0].clientX - touchStartX.current;
    if (Math.abs(deltaX) > SWIPE_THRESHOLD) {
      // swipe left → next image, swipe right → previous image
      goTo(deltaX < 0 ? active + 1 : active - 1);
    }
    touchStartX.current = null;
  }

  return (
    <div>
      <div
        className="relative aspect-[4/5] bg-sand-100 touch-pan-y"
        onTouchStart={handleTouchStart}
        onTouchEnd={handleTouchEnd}
      >
        {current.media_type === "video" ? (
          <video src={current.url} controls className="w-full h-full object-cover" />
        ) : (
          <Image src={current.url} alt="" fill className="object-cover" priority />
        )}
        <div className="absolute bottom-2.5 left-0 right-0 flex justify-center gap-1.5">
          {media.map((_, i) => (
            <span
              key={i}
              className={`w-1.5 h-1.5 rounded-full transition-colors ${i === active ? "bg-ink" : "bg-charcoal/25"}`}
            />
          ))}
        </div>
      </div>

      <div className="flex gap-2 px-4 py-2.5 overflow-x-auto">
        {media.map((m, i) => (
          <button
            key={m.id}
            onClick={() => goTo(i)}
            className={`relative w-13 h-16 flex-shrink-0 rounded-lg overflow-hidden border-2 ${
              i === active ? "border-ink" : "border-transparent"
            }`}
            style={{ width: 52, height: 64 }}
          >
            {m.media_type === "video" ? (
              <div className="w-full h-full bg-sand-100 flex items-center justify-center">
                <PlayCircle size={18} className="text-charcoal/60" />
              </div>
            ) : (
              <Image src={m.url} alt="" fill className="object-cover" />
            )}
          </button>
        ))}
      </div>
    </div>
  );
}
