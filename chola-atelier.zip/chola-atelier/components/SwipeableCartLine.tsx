"use client";

import { useRef, useState } from "react";
import { Trash2 } from "lucide-react";

const DELETE_THRESHOLD = 90; // px of swipe-left needed to auto-delete
const MAX_DRAG = 110;

export default function SwipeableCartLine({
  line,
  onRemove,
  onQtyChange,
}: {
  line: any;
  onRemove: (id: string) => void;
  onQtyChange: (id: string, qty: number) => void;
}) {
  const [dragX, setDragX] = useState(0);
  const startX = useRef<number | null>(null);
  const dragging = useRef(false);

  function handleTouchStart(e: React.TouchEvent) {
    startX.current = e.touches[0].clientX;
    dragging.current = true;
  }

  function handleTouchMove(e: React.TouchEvent) {
    if (startX.current === null) return;
    const delta = e.touches[0].clientX - startX.current;
    // Only allow dragging left (negative), clamp the distance
    setDragX(Math.max(-MAX_DRAG, Math.min(0, delta)));
  }

  function handleTouchEnd() {
    dragging.current = false;
    if (Math.abs(dragX) >= DELETE_THRESHOLD) {
      onRemove(line.id);
    } else {
      setDragX(0); // snap back
    }
    startX.current = null;
  }

  const price = line.product_variants.products.sale_price ?? line.product_variants.products.price;

  return (
    <div className="relative overflow-hidden border-b border-charcoal/10">
      {/* delete background revealed by the swipe */}
      <div className="absolute inset-0 bg-red-500 flex items-center justify-end pr-5">
        <Trash2 size={18} className="text-white" />
      </div>

      <div
        className="relative flex gap-2.5 py-3 bg-cream"
        style={{ transform: `translateX(${dragX}px)`, transition: dragging.current ? "none" : "transform 0.2s ease" }}
        onTouchStart={handleTouchStart}
        onTouchMove={handleTouchMove}
        onTouchEnd={handleTouchEnd}
      >
        <div className="w-14 h-[70px] bg-sand-100 rounded-lg flex-shrink-0" />
        <div className="flex-1">
          <p className="text-sm">{line.product_variants.products.name}</p>
          <p className="text-xs text-charcoal/50 mb-2">{line.product_variants.colour} · {line.product_variants.size}</p>
          <div className="flex items-center gap-2.5">
            <div className="flex items-center border border-charcoal/25 rounded-lg">
              <button onClick={() => onQtyChange(line.id, line.quantity - 1)} className="px-2.5 text-sm">–</button>
              <span className="px-2.5 text-sm border-x border-charcoal/10">{line.quantity}</span>
              <button onClick={() => onQtyChange(line.id, line.quantity + 1)} className="px-2.5 text-sm">+</button>
            </div>
            <button onClick={() => onRemove(line.id)} aria-label="Remove"><Trash2 size={16} className="text-charcoal/40" /></button>
          </div>
        </div>
        <p className="text-sm font-medium">₹{(price * line.quantity).toLocaleString("en-IN")}</p>
      </div>
    </div>
  );
}
