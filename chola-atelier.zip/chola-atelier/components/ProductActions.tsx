"use client";

import { useState } from "react";
import { useRouter } from "next/navigation";
import { ShoppingBag, Zap } from "lucide-react";
import { createClient } from "@/lib/supabase/client";
import type { Product, ProductVariant } from "@/lib/types";

export default function ProductActions({
  product,
  colours,
  sizes,
  variants,
}: {
  product: Product;
  colours: ProductVariant[];
  sizes: string[];
  variants: ProductVariant[];
}) {
  const router = useRouter();
  const [colour, setColour] = useState(colours[0]?.colour ?? "");
  const [size, setSize] = useState(sizes[0] ?? "");
  const [loading, setLoading] = useState<"bag" | "buy" | null>(null);
  const [error, setError] = useState("");

  const selectedVariant = variants.find((v) => v.colour === colour && v.size === size);

  async function handleAddToBag() {
    setError("");
    if (!selectedVariant) return setError("Select a colour and size first.");
    if (selectedVariant.stock < 1) return setError("This variant is out of stock.");

    setLoading("bag");
    const supabase = createClient();
    const { data: { user } } = await supabase.auth.getUser();

    if (!user) {
      setLoading(null);
      router.push("/login?redirect=/cart");
      return;
    }

    // Check for an existing line first — upsert would otherwise overwrite
    // an already-in-cart item's quantity back down to 1 instead of adding to it.
    const { data: existing } = await supabase
      .from("cart_items")
      .select("id, quantity")
      .eq("customer_id", user.id)
      .eq("variant_id", selectedVariant.id)
      .maybeSingle();

    if (existing) {
      await supabase.from("cart_items").update({ quantity: existing.quantity + 1 }).eq("id", existing.id);
    } else {
      await supabase.from("cart_items").insert({ customer_id: user.id, variant_id: selectedVariant.id, quantity: 1 });
    }

    setLoading(null);
    router.push("/cart");
  }

  function handleBuyNow() {
    setError("");
    if (!selectedVariant) return setError("Select a colour and size first.");
    if (selectedVariant.stock < 1) return setError("This variant is out of stock.");

    // "Buy now" skips the cart entirely — go straight to checkout with
    // this single item passed via query params (read on the checkout page).
    setLoading("buy");
    const params = new URLSearchParams({
      mode: "buy-now",
      variantId: selectedVariant.id,
      productId: product.id,
      qty: "1",
    });
    router.push(`/checkout?${params.toString()}`);
  }

  return (
    <div>
      <p className="text-sm text-charcoal/60 mb-1.5">Colour · {colour}</p>
      <div className="flex gap-2 mb-4">
        {colours.map((c) => (
          <button
            key={c.colour}
            onClick={() => setColour(c.colour)}
            className={`w-6.5 h-6.5 rounded-full border-2 ${colour === c.colour ? "border-ink" : "border-transparent"}`}
            style={{ width: 26, height: 26, backgroundColor: c.colour_hex }}
            aria-label={c.colour}
          />
        ))}
      </div>

      <p className="text-sm text-charcoal/60 mb-1.5">Size · {size}</p>
      <div className="flex gap-2 mb-4">
        {sizes.map((s) => (
          <button
            key={s}
            onClick={() => setSize(s)}
            className={`text-sm px-3 py-1.5 rounded-lg border ${
              size === s ? "border-ink border-2" : "border-charcoal/25"
            }`}
          >
            {s}
          </button>
        ))}
      </div>

      {error && <p className="text-xs text-red-600 mb-3">{error}</p>}

      <div className="flex gap-2.5">
        <button onClick={handleAddToBag} disabled={loading !== null} className="btn-secondary flex-1 flex items-center justify-center gap-1.5">
          <ShoppingBag size={16} /> {loading === "bag" ? "Adding…" : "Add to bag"}
        </button>
        <button onClick={handleBuyNow} disabled={loading !== null} className="btn-primary flex-1 flex items-center justify-center gap-1.5">
          <Zap size={16} /> {loading === "buy" ? "Loading…" : "Buy now"}
        </button>
      </div>
    </div>
  );
}
