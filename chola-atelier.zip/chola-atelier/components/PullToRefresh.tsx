"use client";

import { useRef, useState } from "react";
import { useRouter } from "next/navigation";
import { Loader2 } from "lucide-react";

const PULL_THRESHOLD = 70; // px of downward pull needed to trigger a refresh
const MAX_PULL = 100;

export default function PullToRefresh({ children }: { children: React.ReactNode }) {
  const router = useRouter();
  const [pullY, setPullY] = useState(0);
  const [refreshing, setRefreshing] = useState(false);
  const startY = useRef<number | null>(null);
  const containerRef = useRef<HTMLDivElement>(null);

  function handleTouchStart(e: React.TouchEvent) {
    // only start tracking a pull if the page is already scrolled to the very top
    if (window.scrollY === 0) {
      startY.current = e.touches[0].clientY;
    }
  }

  function handleTouchMove(e: React.TouchEvent) {
    if (startY.current === null || refreshing) return;
    const delta = e.touches[0].clientY - startY.current;
    if (delta > 0) {
      setPullY(Math.min(MAX_PULL, delta * 0.5)); // 0.5 = resistance, feels more natural than 1:1
    }
  }

  async function handleTouchEnd() {
    if (pullY >= PULL_THRESHOLD) {
      setRefreshing(true);
      setPullY(PULL_THRESHOLD);
      router.refresh();
      // brief pause so the spinner is visible even on a fast cached refresh
      setTimeout(() => {
        setRefreshing(false);
        setPullY(0);
      }, 700);
    } else {
      setPullY(0);
    }
    startY.current = null;
  }

  return (
    <div
      ref={containerRef}
      onTouchStart={handleTouchStart}
      onTouchMove={handleTouchMove}
      onTouchEnd={handleTouchEnd}
    >
      <div
        className="flex items-center justify-center overflow-hidden text-charcoal/40"
        style={{ height: pullY, transition: startY.current === null ? "height 0.2s ease" : "none" }}
      >
        <Loader2 size={18} className={refreshing ? "animate-spin" : ""} />
      </div>
      {children}
    </div>
  );
}
