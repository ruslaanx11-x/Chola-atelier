import Link from "next/link";
import Image from "next/image";
import type { Product } from "@/lib/types";

export default function ProductCard({ product }: { product: Product & { slug: string } }) {
  const mainImage = product.product_media?.find((m) => m.media_type === "image");
  const price = product.sale_price ?? product.price;

  const discount =
    product.sale_price && product.price > product.sale_price
      ? Math.round(((product.price - product.sale_price) / product.price) * 100)
      : 0;

  // Only ONE badge shows at a time (priority: sale > new > bestseller) so
  // badges never stack on top of each other either.
  const badge = discount > 0
    ? `${discount}% off`
    : product.is_new_arrival
    ? "New"
    : product.is_best_seller
    ? "Bestseller"
    : null;

  return (
    <Link href={`/product/${product.slug}`} className="block">
      {/* Image box is its own isolated container — badge is absolutely
          positioned INSIDE it only, so it can never reach the text below. */}
      <div className="relative aspect-[3/4] rounded-card bg-sand-100 overflow-hidden">
        {mainImage ? (
          <Image src={mainImage.url} alt={product.name} fill className="object-cover" />
        ) : (
          <div className="w-full h-full flex items-center justify-center text-charcoal/30 text-xs">
            No image
          </div>
        )}

        {badge && (
          <span
            className="absolute top-2 left-2 text-[11px] font-medium text-white px-2 py-0.5 rounded-full border border-white/25"
            style={{
              background: "rgba(255, 255, 255, 0.12)",
              backdropFilter: "blur(6px) saturate(140%)",
              WebkitBackdropFilter: "blur(6px) saturate(140%)",
              textShadow: "0 1px 3px rgba(0,0,0,0.55)",
            }}
          >
            {badge}
          </span>
        )}
      </div>

      {/* Text sits in normal document flow, fully outside the image box —
          truncated to one line each so long names can never push into price. */}
      <p className="text-sm mt-1.5 truncate">{product.name}</p>
      <div className="flex items-baseline gap-1.5">
        <p className="text-sm font-medium">₹{price?.toLocaleString("en-IN")}</p>
        {discount > 0 && (
          <p className="text-xs text-charcoal/40 line-through">₹{product.price.toLocaleString("en-IN")}</p>
        )}
      </div>
    </Link>
  );
}
