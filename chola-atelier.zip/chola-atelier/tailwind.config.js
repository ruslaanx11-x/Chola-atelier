/** @type {import('tailwindcss').Config} */
module.exports = {
  content: ["./app/**/*.{js,ts,jsx,tsx}", "./components/**/*.{js,ts,jsx,tsx}"],
  theme: {
    extend: {
      colors: {
        cream: "#F7F2EA",
        ink: "#241E19",
        rust: {
          50: "#FAECE7",
          400: "#D85A30",
          600: "#993C1D",
          800: "#4A1B0C",
        },
        sand: {
          100: "#EFE8D8",
          300: "#DBCFB4",
        },
        charcoal: "#3A332C",
      },
      fontFamily: {
        display: ["Cormorant Garamond", "Georgia", "serif"],
        sans: ["Inter", "system-ui", "sans-serif"],
      },
      borderRadius: {
        card: "12px",
      },
    },
  },
  plugins: [],
};
