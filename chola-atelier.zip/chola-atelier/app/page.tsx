import { createClient } from "@/lib/supabase/server";
import ProductCard from "@/components/ProductCard";
import PullToRefresh from "@/components/PullToRefresh";
import Link from "next/link";

export const revalidate = 60; // re-fetch from cloud DB at most once a minute

export default async function HomePage() {
  const supabase = createClient();

  const { data: categories } = await supabase
    .from("categories")
    .select("id, name, slug")
    .is("parent_id", null)
    .order("sort_order");

  const { data: bestSellers } = await supabase
    .from("products")
    .select("*, product_media(*), product_variants(*)")
    .eq("is_best_seller", true)
    .limit(6);

  return (
    <PullToRefresh>
    <main>
      <section className="m-4 rounded-card bg-rust-50 px-4 py-6 text-center">
        <p className="text-xs tracking-wide text-rust-600 mb-1">new arrivals</p>
        <h1 className="font-display text-2xl mb-3">The festive edit</h1>
        <Link href="/collection/festive-edit" className="btn-secondary inline-block px-6 w-auto">
          Shop now
        </Link>
      </section>

      <div className="flex gap-2 px-4 pb-4 overflow-x-auto">
        {(categories ?? []).map((c) => (
          <Link key={c.id} href={`/category/${c.slug}`} className="chip">
            {c.name}
          </Link>
        ))}
      </div>

      <p className="text-sm text-charcoal/60 px-4 mb-2">Best sellers</p>
      <div className="grid grid-cols-2 gap-3 px-4 pb-6">
        {(bestSellers ?? []).map((p) => (
          <ProductCard key={p.id} product={p as any} />
        ))}
        {(!bestSellers || bestSellers.length === 0) && (
          <p className="col-span-2 text-sm text-charcoal/50">
            No products yet — add some from /admin.
          </p>
        )}
      </div>
    </main>
    </PullToRefresh>
  );
}
