import { createClient } from "@/lib/supabase/server";
import ProductCard from "@/components/ProductCard";

export const revalidate = 60;

export default async function ShopPage() {
  const supabase = createClient();
  const { data: products } = await supabase
    .from("products")
    .select("*, product_media(*), product_variants(*)")
    .order("created_at", { ascending: false });

  return (
    <main className="p-4">
      <h1 className="font-display text-xl mb-4">Shop all</h1>
      <div className="grid grid-cols-2 gap-3">
        {(products ?? []).map((p) => (
          <ProductCard key={p.id} product={p as any} />
        ))}
      </div>
      {(!products || products.length === 0) && (
        <p className="text-sm text-charcoal/50">No products yet — add some from /admin.</p>
      )}
    </main>
  );
}
