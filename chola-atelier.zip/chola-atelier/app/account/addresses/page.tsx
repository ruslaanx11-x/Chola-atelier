import { createClient } from "@/lib/supabase/server";
import { redirect } from "next/navigation";
import Link from "next/link";
import { MapPin } from "lucide-react";

export default async function AddressesPage() {
  const supabase = createClient();
  const { data: { user } } = await supabase.auth.getUser();
  if (!user) redirect("/login?redirect=/account/addresses");

  const { data: addresses } = await supabase
    .from("addresses")
    .select("*")
    .eq("customer_id", user.id)
    .order("is_default", { ascending: false });

  async function setDefault(formData: FormData) {
    "use server";
    const id = formData.get("id") as string;
    const supabase = createClient();
    const { data: { user } } = await supabase.auth.getUser();
    if (!user) return;
    await supabase.from("addresses").update({ is_default: false }).eq("customer_id", user.id);
    await supabase.from("addresses").update({ is_default: true }).eq("id", id);
    redirect("/account/addresses");
  }

  return (
    <main className="p-4">
      <div className="flex justify-between items-center mb-4">
        <h1 className="text-base font-medium">Addresses</h1>
        <Link href="/account/addresses/new" className="text-xs text-rust-600">+ Add new</Link>
      </div>

      {(addresses ?? []).map((a) => (
        <div key={a.id} className="border border-charcoal/15 rounded-card p-3 mb-3">
          <div className="flex items-start gap-2.5">
            <MapPin size={16} className="mt-0.5 text-charcoal/40" />
            <div className="flex-1">
              <p className="text-sm font-medium">{a.full_name} · {a.label}</p>
              <p className="text-sm text-charcoal/60">{a.line1}{a.line2 ? `, ${a.line2}` : ""}, {a.city}, {a.state} {a.pincode}</p>
              <p className="text-xs text-charcoal/40 mt-1">{a.phone}</p>
            </div>
          </div>
          {a.is_default ? (
            <span className="inline-block mt-2 text-[11px] px-2 py-0.5 rounded-full bg-rust-50 text-rust-600">Default</span>
          ) : (
            <form action={setDefault} className="mt-2">
              <input type="hidden" name="id" value={a.id} />
              <button type="submit" className="text-xs text-rust-600">Set as default</button>
            </form>
          )}
        </div>
      ))}

      {(!addresses || addresses.length === 0) && (
        <p className="text-sm text-charcoal/50">No saved addresses yet.</p>
      )}
    </main>
  );
}
