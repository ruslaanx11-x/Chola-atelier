"use client";

import { useState } from "react";
import { useRouter } from "next/navigation";
import { createClient } from "@/lib/supabase/client";

export default function NewAddressPage() {
  const router = useRouter();
  const [form, setForm] = useState({
    label: "home", full_name: "", phone: "", line1: "", line2: "", city: "", state: "", pincode: "",
  });
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState("");

  function update(key: string, value: string) {
    setForm((f) => ({ ...f, [key]: value }));
  }

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    setSaving(true);
    setError("");
    const supabase = createClient();
    const { data: { user } } = await supabase.auth.getUser();
    if (!user) return router.push("/login?redirect=/account/addresses/new");

    // First address for this customer becomes the default automatically —
    // otherwise checkout would still show "no address" right after adding one.
    const { count } = await supabase
      .from("addresses")
      .select("id", { count: "exact", head: true })
      .eq("customer_id", user.id);

    const { error } = await supabase.from("addresses").insert({
      ...form,
      customer_id: user.id,
      is_default: (count ?? 0) === 0,
    });

    setSaving(false);
    if (error) return setError(error.message);
    router.push("/account/addresses");
  }

  return (
    <main className="p-4">
      <h1 className="text-base font-medium mb-4">Add address</h1>
      <form onSubmit={handleSubmit} className="flex flex-col gap-3">
        <div className="flex gap-2">
          {["home", "work", "other"].map((l) => (
            <button
              type="button"
              key={l}
              onClick={() => update("label", l)}
              className={`text-xs px-3 py-1.5 rounded-full border capitalize ${
                form.label === l ? "border-ink border-2" : "border-charcoal/25"
              }`}
            >
              {l}
            </button>
          ))}
        </div>

        <input required placeholder="Full name" value={form.full_name} onChange={(e) => update("full_name", e.target.value)} className="border border-charcoal/25 rounded-card px-3 py-2.5 text-sm" />
        <input required placeholder="Phone number" value={form.phone} onChange={(e) => update("phone", e.target.value)} className="border border-charcoal/25 rounded-card px-3 py-2.5 text-sm" />
        <input required placeholder="House no., street, area" value={form.line1} onChange={(e) => update("line1", e.target.value)} className="border border-charcoal/25 rounded-card px-3 py-2.5 text-sm" />
        <input placeholder="Landmark (optional)" value={form.line2} onChange={(e) => update("line2", e.target.value)} className="border border-charcoal/25 rounded-card px-3 py-2.5 text-sm" />
        <div className="flex gap-3">
          <input required placeholder="City" value={form.city} onChange={(e) => update("city", e.target.value)} className="border border-charcoal/25 rounded-card px-3 py-2.5 text-sm flex-1" />
          <input required placeholder="State" value={form.state} onChange={(e) => update("state", e.target.value)} className="border border-charcoal/25 rounded-card px-3 py-2.5 text-sm flex-1" />
        </div>
        <input required placeholder="Pincode" value={form.pincode} onChange={(e) => update("pincode", e.target.value)} className="border border-charcoal/25 rounded-card px-3 py-2.5 text-sm" />

        {error && <p className="text-xs text-red-600">{error}</p>}
        <button type="submit" disabled={saving} className="btn-primary mt-1">
          {saving ? "Saving…" : "Save address"}
        </button>
      </form>
    </main>
  );
}
