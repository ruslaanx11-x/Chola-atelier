import { createClient } from "@/lib/supabase/server";
import { redirect } from "next/navigation";
import Link from "next/link";

export default async function OrdersPage() {
  const supabase = createClient();
  const { data: { user } } = await supabase.auth.getUser();
  if (!user) redirect("/login?redirect=/account/orders");

  const { data: orders } = await supabase
    .from("orders")
    .select("id, order_number, total, order_status, created_at")
    .eq("customer_id", user.id)
    .order("created_at", { ascending: false });

  return (
    <main className="p-4">
      <h1 className="text-base font-medium mb-4">Your orders</h1>
      {(orders ?? []).map((o) => (
        <Link key={o.id} href={`/account/orders/${o.id}`} className="flex justify-between items-center py-2.5 border-b border-charcoal/10">
          <div>
            <p className="text-sm">{o.order_number}</p>
            <p className="text-xs text-charcoal/40">{new Date(o.created_at).toLocaleDateString("en-IN")}</p>
          </div>
          <div className="text-right">
            <span className="text-xs px-2 py-0.5 rounded-full bg-rust-50 text-rust-600 capitalize">{o.order_status}</span>
            <p className="text-sm font-medium mt-1">₹{o.total.toLocaleString("en-IN")}</p>
          </div>
        </Link>
      ))}
      {(!orders || orders.length === 0) && <p className="text-sm text-charcoal/50">No orders yet.</p>}
    </main>
  );
}
