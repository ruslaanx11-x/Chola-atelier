import { createClient } from "@/lib/supabase/server";
import { notFound, redirect } from "next/navigation";
import { Truck } from "lucide-react";

const STEPS = ["placed", "packed", "shipped", "delivered"] as const;

export default async function OrderTrackingPage({ params }: { params: { id: string } }) {
  const supabase = createClient();
  const { data: { user } } = await supabase.auth.getUser();
  if (!user) redirect(`/login?redirect=/account/orders/${params.id}`);

  const { data: order } = await supabase
    .from("orders")
    .select("*, order_items(*)")
    .eq("id", params.id)
    .eq("customer_id", user.id) // ensures a customer can only ever open their own order
    .single();

  if (!order) return notFound();

  const currentStepIndex = STEPS.indexOf(order.order_status as any);

  return (
    <main className="p-4">
      <h1 className="text-base font-medium mb-4">Track order</h1>

      <div className="bg-sand-100 rounded-card p-3.5 mb-5">
        <p className="text-xs text-charcoal/50 mb-1">order</p>
        <p className="text-sm">{order.order_number} · {order.order_items.length} item{order.order_items.length > 1 ? "s" : ""}</p>
      </div>

      <p className="text-xs text-charcoal/50 mb-3 tracking-wide">status</p>
      {STEPS.map((step, i) => {
        const done = i <= currentStepIndex;
        const isLast = i === STEPS.length - 1;
        return (
          <div key={step} className="flex items-start mb-1">
            <div className="flex flex-col items-center mr-3.5">
              <span className={`w-3 h-3 rounded-full ${done ? "bg-charcoal" : "bg-charcoal/20"}`} />
              {!isLast && <span className={`w-0.5 h-7 ${done ? "bg-charcoal" : "bg-charcoal/20"}`} />}
            </div>
            <p className={`text-sm capitalize ${done ? "font-medium" : "text-charcoal/40"}`}>{step}</p>
          </div>
        );
      })}

      {order.tracking_id && (
        <div className="flex items-center gap-2.5 p-3 bg-sand-100 rounded-card mt-4">
          <Truck size={20} />
          <div>
            <p className="text-sm">{order.courier_name ?? "Courier partner"}</p>
            <p className="text-xs text-charcoal/50">Tracking ID: {order.tracking_id}</p>
          </div>
        </div>
      )}
    </main>
  );
}
