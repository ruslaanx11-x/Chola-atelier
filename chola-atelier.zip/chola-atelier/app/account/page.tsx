import { createClient } from "@/lib/supabase/server";
import { redirect } from "next/navigation";
import Link from "next/link";

export default async function AccountPage() {
  const supabase = createClient();
  const { data: { user } } = await supabase.auth.getUser();
  if (!user) redirect("/login?redirect=/account");

  const { data: customer } = await supabase.from("customers").select("full_name").eq("id", user.id).single();
  const { data: orders } = await supabase
    .from("orders")
    .select("id, order_number, total, order_status, created_at")
    .eq("customer_id", user.id)
    .order("created_at", { ascending: false });

  const initials = (customer?.full_name ?? user.email ?? "?").slice(0, 2).toUpperCase();

  return (
    <main className="p-4">
      <div className="flex items-center gap-3 mb-5">
        <div className="w-11 h-11 rounded-full bg-rust-50 text-rust-600 flex items-center justify-center text-sm font-medium">
          {initials}
        </div>
        <div>
          <p className="text-sm font-medium">{customer?.full_name ?? user.email}</p>
        </div>
      </div>

      <div className="grid grid-cols-2 gap-2.5 mb-6">
        <Link href="/account/orders" className="bg-sand-100 rounded-card p-3 text-sm">Orders</Link>
        <Link href="/wishlist" className="bg-sand-100 rounded-card p-3 text-sm">Wishlist</Link>
        <Link href="/account/addresses" className="bg-sand-100 rounded-card p-3 text-sm">Addresses</Link>
        <Link href="/contact" className="bg-sand-100 rounded-card p-3 text-sm">Support</Link>
      </div>

      <p className="text-xs text-charcoal/50 mb-2 tracking-wide">order history</p>
      {(orders ?? []).map((o) => (
        <Link key={o.id} href={`/account/orders/${o.id}`} className="flex justify-between items-center py-2.5 border-b border-charcoal/10">
          <div>
            <p className="text-sm">{o.order_number}</p>
            <p className="text-xs text-charcoal/40">{new Date(o.created_at).toLocaleDateString("en-IN")}</p>
          </div>
          <div className="text-right">
            <span className="text-xs px-2 py-0.5 rounded-full bg-rust-50 text-rust-600 capitalize">{o.order_status}</span>
            <p className="text-sm font-medium mt-1">₹{o.total.toLocaleString("en-IN")}</p>
          </div>
        </Link>
      ))}
      {(!orders || orders.length === 0) && <p className="text-sm text-charcoal/50">No orders yet.</p>}
    </main>
  );
}
