import { createClient } from "@/lib/supabase/server";
import { notFound } from "next/navigation";
import { CheckCircle2 } from "lucide-react";
import Link from "next/link";

export default async function OrderConfirmationPage({ params }: { params: { id: string } }) {
  const supabase = createClient();
  const { data: order } = await supabase
    .from("orders")
    .select("*, order_items(*)")
    .eq("id", params.id)
    .single();

  if (!order) return notFound();

  return (
    <main className="p-4">
      <div className="text-center py-6 border-b border-charcoal/10 mb-4">
        <div className="w-13 h-13 rounded-full bg-green-50 flex items-center justify-center mx-auto mb-3" style={{ width: 52, height: 52 }}>
          <CheckCircle2 size={26} className="text-green-600" />
        </div>
        <h1 className="font-display text-lg mb-1">Order confirmed</h1>
        <p className="text-sm text-charcoal/60">We&apos;ll notify you as it ships</p>
      </div>

      <div className="flex justify-between py-2.5 border-b border-charcoal/10 text-sm">
        <span className="text-charcoal/60">Order number</span><span className="font-medium">{order.order_number}</span>
      </div>
      <div className="flex justify-between py-2.5 border-b border-charcoal/10 text-sm">
        <span className="text-charcoal/60">Payment method</span><span className="uppercase">{order.payment_method}</span>
      </div>
      <div className="flex justify-between py-2.5 mb-4 text-sm">
        <span className="text-charcoal/60">Total paid</span><span className="font-medium">₹{order.total.toLocaleString("en-IN")}</span>
      </div>

      <Link href={`/account/orders/${order.id}`} className="btn-primary block mb-2">Track order</Link>
      <Link href="/" className="btn-secondary block">Continue shopping</Link>
    </main>
  );
}
