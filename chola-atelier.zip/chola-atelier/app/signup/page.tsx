"use client";

import { useState } from "react";
import { useRouter } from "next/navigation";
import { createClient } from "@/lib/supabase/client";
import Link from "next/link";

export default function SignupPage() {
  const router = useRouter();
  const [fullName, setFullName] = useState("");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [error, setError] = useState("");
  const [loading, setLoading] = useState(false);
  const [checkEmail, setCheckEmail] = useState(false);

  async function handleSignup(e: React.FormEvent) {
    e.preventDefault();
    setLoading(true);
    setError("");
    const supabase = createClient();

    // full_name is passed as user metadata — a database trigger (see
    // supabase/schema.sql) reads it to create the matching `customers`
    // row automatically. We deliberately do NOT insert into `customers`
    // from here: right after signUp there may be no active session yet
    // (if email confirmation is required), and Row Level Security would
    // silently reject a client-side insert in that case.
    const { data, error } = await supabase.auth.signUp({
      email,
      password,
      options: { data: { full_name: fullName } },
    });

    setLoading(false);
    if (error) return setError(error.message);

    if (!data.session) {
      // Email confirmation is required — there's nothing more to do
      // until they click the link in their inbox.
      setCheckEmail(true);
      return;
    }

    router.push("/");
  }

  if (checkEmail) {
    return (
      <main className="p-4">
        <h1 className="font-display text-xl mb-2">Check your email</h1>
        <p className="text-sm text-charcoal/60">
          We&apos;ve sent a confirmation link to {email}. Tap it to activate your account, then log in.
        </p>
      </main>
    );
  }

  return (
    <main className="p-4">
      <h1 className="font-display text-xl mb-4">Create account</h1>
      <form onSubmit={handleSignup} className="flex flex-col gap-3">
        <input required placeholder="Full name" value={fullName} onChange={(e) => setFullName(e.target.value)}
          className="border border-charcoal/25 rounded-card px-3 py-2.5 text-sm" />
        <input type="email" required placeholder="Email" value={email} onChange={(e) => setEmail(e.target.value)}
          className="border border-charcoal/25 rounded-card px-3 py-2.5 text-sm" />
        <input type="password" required minLength={6} placeholder="Password" value={password} onChange={(e) => setPassword(e.target.value)}
          className="border border-charcoal/25 rounded-card px-3 py-2.5 text-sm" />
        {error && <p className="text-xs text-red-600">{error}</p>}
        <button type="submit" disabled={loading} className="btn-primary mt-1">
          {loading ? "Creating…" : "Create account"}
        </button>
      </form>
      <p className="text-sm text-charcoal/60 mt-4">
        Already have an account? <Link href="/login" className="text-rust-600">Log in</Link>
      </p>
    </main>
  );
}
