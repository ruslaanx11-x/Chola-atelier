"use client";

import { Suspense } from "react";

import { useEffect, useState } from "react";
import { useRouter, useSearchParams } from "next/navigation";
import { createClient } from "@/lib/supabase/client";
import { QrCode, CreditCard, Truck } from "lucide-react";

type Line = { variant_id: string; product_name: string; colour: string; size: string; quantity: number; price: number; image?: string };

declare global {
  interface Window { Razorpay: any; }
}

function CheckoutPageInner() {
  const router = useRouter();
  const params = useSearchParams();
  const isBuyNow = params.get("mode") === "buy-now";

  const [lines, setLines] = useState<Line[]>([]);
  const [address, setAddress] = useState<any>(null);
  const [payment, setPayment] = useState<"upi" | "card" | "cod">("upi");
  const [placing, setPlacing] = useState(false);

  useEffect(() => {
    const supabase = createClient();
    (async () => {
      const { data: { user } } = await supabase.auth.getUser();
      if (!user) return router.push("/login?redirect=/checkout");

      const { data: addr } = await supabase
        .from("addresses")
        .select("*")
        .eq("customer_id", user.id)
        .eq("is_default", true)
        .maybeSingle();
      setAddress(addr);

      if (isBuyNow) {
        const variantId = params.get("variantId")!;
        const { data: variant } = await supabase
          .from("product_variants")
          .select("*, products(name, price, sale_price)")
          .eq("id", variantId)
          .single();
        if (variant) {
          setLines([{
            variant_id: variant.id,
            product_name: variant.products.name,
            colour: variant.colour,
            size: variant.size,
            quantity: Number(params.get("qty") ?? 1),
            price: variant.products.sale_price ?? variant.products.price,
          }]);
        }
      } else {
        const { data: cart } = await supabase
          .from("cart_items")
          .select("*, product_variants(*, products(name, price, sale_price))")
          .eq("customer_id", user.id);
        setLines(
          (cart ?? []).map((c: any) => ({
            variant_id: c.variant_id,
            product_name: c.product_variants.products.name,
            colour: c.product_variants.colour,
            size: c.product_variants.size,
            quantity: c.quantity,
            price: c.product_variants.products.sale_price ?? c.product_variants.products.price,
          }))
        );
      }
    })();
  }, [isBuyNow]); // eslint-disable-line react-hooks/exhaustive-deps

  const subtotal = lines.reduce((sum, l) => sum + l.price * l.quantity, 0);
  const shipping = subtotal >= 999 || subtotal === 0 ? 0 : 79;
  const total = subtotal + shipping;

  async function placeOrder() {
    setPlacing(true);
    try {
      const res = await fetch("/api/orders/create", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ lines, addressId: address?.id, paymentMethod: payment, isBuyNow, total, subtotal }),
      });
      const order = await res.json();
      if (!res.ok) throw new Error(order.error ?? "Could not place order");

      if (payment === "cod") {
        router.push(`/order-confirmation/${order.id}`);
        return;
      }

      // Razorpay flow — server already created a razorpay_order_id
      const rzp = new window.Razorpay({
        key: process.env.NEXT_PUBLIC_RAZORPAY_KEY_ID,
        amount: Math.round(total * 100),
        currency: "INR",
        name: "Chola Atelier",
        order_id: order.razorpayOrderId,
        handler: async (response: any) => {
          await fetch("/api/razorpay/verify", {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({ ...response, orderId: order.id }),
          });
          router.push(`/order-confirmation/${order.id}`);
        },
        theme: { color: "#241E19" },
      });
      rzp.open();
    } catch (e: any) {
      alert(e.message);
    } finally {
      setPlacing(false);
    }
  }

  return (
    <main className="p-4">
      <script src="https://checkout.razorpay.com/v1/checkout.js" async />

      <h1 className="text-base font-medium mb-4">{isBuyNow ? "Buy now" : "Checkout"}</h1>

      {isBuyNow && (
        <div className="flex items-center gap-2 bg-rust-50 text-rust-600 text-xs rounded-card px-3 py-2 mb-4">
          Direct checkout · skips your bag
        </div>
      )}

      <p className="text-xs text-charcoal/50 mb-2 tracking-wide">deliver to</p>
      {address ? (
        <div className="bg-sand-100 rounded-card p-3 mb-4 flex justify-between items-start">
          <div>
            <p className="text-sm font-medium">{address.full_name} · {address.label}</p>
            <p className="text-sm text-charcoal/60">{address.line1}, {address.city}, {address.state} {address.pincode}</p>
          </div>
          <button onClick={() => router.push("/account/addresses")} className="text-xs text-rust-600">change</button>
        </div>
      ) : (
        <button onClick={() => router.push("/account/addresses/new")} className="btn-secondary mb-4">
          Add a delivery address
        </button>
      )}

      <p className="text-xs text-charcoal/50 mb-2 tracking-wide">
        {isBuyNow ? "item" : "order summary"}
      </p>
      <div className="mb-4">
        {lines.map((l) => (
          <div key={l.variant_id} className="flex gap-2.5 py-2 border-b border-charcoal/10">
            <div className="w-11 h-14 bg-sand-100 rounded-lg flex-shrink-0" />
            <div className="flex-1">
              <p className="text-sm">{l.product_name}</p>
              <p className="text-xs text-charcoal/50">{l.colour} · {l.size} · Qty {l.quantity}</p>
            </div>
            <p className="text-sm font-medium">₹{(l.price * l.quantity).toLocaleString("en-IN")}</p>
          </div>
        ))}
      </div>

      <p className="text-xs text-charcoal/50 mb-2 tracking-wide">payment method</p>
      <div className="flex flex-col gap-2 mb-4">
        {[
          { id: "upi", label: "UPI", icon: QrCode },
          { id: "card", label: "Card / net banking", icon: CreditCard },
          { id: "cod", label: "Cash on delivery", icon: Truck },
        ].map(({ id, label, icon: Icon }) => (
          <label
            key={id}
            className={`flex items-center gap-2.5 px-3 py-2.5 rounded-card border ${
              payment === id ? "border-ink border-2" : "border-charcoal/20"
            }`}
          >
            <input type="radio" name="pay" checked={payment === id} onChange={() => setPayment(id as any)} />
            <Icon size={18} />
            <span className="text-sm">{label}</span>
          </label>
        ))}
      </div>

      <div className="border-t border-charcoal/10 pt-3 mb-4 text-sm">
        <div className="flex justify-between text-charcoal/60 mb-1.5">
          <span>Subtotal</span><span>₹{subtotal.toLocaleString("en-IN")}</span>
        </div>
        <div className="flex justify-between text-charcoal/60 mb-1.5">
          <span>Shipping</span><span>{shipping === 0 ? "Free" : `₹${shipping}`}</span>
        </div>
        <div className="flex justify-between font-medium text-base mt-2">
          <span>Total</span><span>₹{total.toLocaleString("en-IN")}</span>
        </div>
      </div>

      <button onClick={placeOrder} disabled={placing || lines.length === 0 || !address} className="btn-primary">
        {placing ? "Placing order…" : payment === "cod" ? "Place order" : `Pay ₹${total.toLocaleString("en-IN")}`}
      </button>
    </main>
  );
}

export default function CheckoutPage() {
  return (
    <Suspense fallback={<main className="p-4 text-sm text-charcoal/50">Loading checkout…</main>}>
      <CheckoutPageInner />
    </Suspense>
  );
}
