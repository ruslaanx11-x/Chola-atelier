import { createClient } from "@/lib/supabase/server";
import { Mail, Phone, MessageCircle } from "lucide-react";

export default async function ContactPage() {
  const supabase = createClient();
  const { data: settings } = await supabase.from("store_settings").select("*").eq("id", 1).single();

  return (
    <main className="p-4">
      <h1 className="font-display text-xl mb-4">Get in touch</h1>
      <div className="flex flex-col gap-3">
        {settings?.contact_email && (
          <a href={`mailto:${settings.contact_email}`} className="flex items-center gap-3 bg-sand-100 rounded-card p-3">
            <Mail size={18} />
            <span className="text-sm">{settings.contact_email}</span>
          </a>
        )}
        {settings?.contact_phone && (
          <a href={`tel:${settings.contact_phone}`} className="flex items-center gap-3 bg-sand-100 rounded-card p-3">
            <Phone size={18} />
            <span className="text-sm">{settings.contact_phone}</span>
          </a>
        )}
        {settings?.whatsapp_number && (
          <a href={`https://wa.me/${settings.whatsapp_number}`} target="_blank" className="flex items-center gap-3 bg-sand-100 rounded-card p-3">
            <MessageCircle size={18} />
            <span className="text-sm">Chat on WhatsApp</span>
          </a>
        )}
        {!settings?.contact_email && !settings?.contact_phone && !settings?.whatsapp_number && (
          <p className="text-sm text-charcoal/50">
            Add your contact details in the <code>store_settings</code> table from the Supabase dashboard.
          </p>
        )}
      </div>
    </main>
  );
}
