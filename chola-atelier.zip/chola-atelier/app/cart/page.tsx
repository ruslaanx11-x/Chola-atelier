"use client";

import { useEffect, useState } from "react";
import { useRouter } from "next/navigation";
import { createClient } from "@/lib/supabase/client";
import SwipeableCartLine from "@/components/SwipeableCartLine";

export default function CartPage() {
  const router = useRouter();
  const [lines, setLines] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const supabase = createClient();

  async function load() {
    const { data: { user } } = await supabase.auth.getUser();
    if (!user) return router.push("/login?redirect=/cart");
    const { data } = await supabase
      .from("cart_items")
      .select("*, product_variants(*, products(name, price, sale_price))")
      .eq("customer_id", user.id);
    setLines(data ?? []);
    setLoading(false);
  }

  useEffect(() => { load(); }, []); // eslint-disable-line react-hooks/exhaustive-deps

  async function updateQty(id: string, qty: number) {
    if (qty < 1) return removeLine(id);
    await supabase.from("cart_items").update({ quantity: qty }).eq("id", id);
    load();
  }

  async function removeLine(id: string) {
    setLines((prev) => prev.filter((l) => l.id !== id)); // optimistic — feels instant on swipe
    await supabase.from("cart_items").delete().eq("id", id);
  }

  const subtotal = lines.reduce((sum, l) => {
    const price = l.product_variants.products.sale_price ?? l.product_variants.products.price;
    return sum + price * l.quantity;
  }, 0);

  if (loading) return <main className="p-4 text-sm text-charcoal/50">Loading your bag…</main>;

  return (
    <main className="p-4">
      <h1 className="text-base font-medium mb-4">Bag ({lines.length})</h1>

      {lines.length === 0 && <p className="text-sm text-charcoal/50">Your bag is empty.</p>}
      {lines.length > 0 && (
        <p className="text-xs text-charcoal/40 mb-2">Swipe an item left to remove it</p>
      )}

      {lines.map((l) => (
        <SwipeableCartLine key={l.id} line={l} onRemove={removeLine} onQtyChange={updateQty} />
      ))}

      {lines.length > 0 && (
        <>
          <div className="border-t border-charcoal/10 pt-3 mt-4 mb-4 flex justify-between font-medium">
            <span>Total</span><span>₹{subtotal.toLocaleString("en-IN")}</span>
          </div>
          <button onClick={() => router.push("/checkout")} className="btn-primary">Checkout</button>
        </>
      )}
    </main>
  );
}
