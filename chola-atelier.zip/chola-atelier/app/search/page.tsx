"use client";

import { useState } from "react";
import { Search as SearchIcon } from "lucide-react";
import { createClient } from "@/lib/supabase/client";
import ProductCard from "@/components/ProductCard";

export default function SearchPage() {
  const [query, setQuery] = useState("");
  const [results, setResults] = useState<any[]>([]);
  const [loading, setLoading] = useState(false);
  const [searched, setSearched] = useState(false);

  async function handleSearch(e: React.FormEvent) {
    e.preventDefault();
    if (!query.trim()) return;
    setLoading(true);
    setSearched(true);
    const supabase = createClient();
    const { data } = await supabase
      .from("products")
      .select("*, product_media(*), product_variants(*)")
      .ilike("name", `%${query.trim()}%`)
      .limit(20);
    setResults(data ?? []);
    setLoading(false);
  }

  return (
    <main className="p-4">
      <form onSubmit={handleSearch} className="flex items-center gap-2 border border-charcoal/25 rounded-card px-3 py-2.5 mb-4">
        <SearchIcon size={16} className="text-charcoal/40" />
        <input
          autoFocus
          placeholder="Search kurtis, jewellery, accessories…"
          value={query}
          onChange={(e) => setQuery(e.target.value)}
          className="flex-1 text-sm outline-none bg-transparent"
        />
      </form>

      {loading && <p className="text-sm text-charcoal/50">Searching…</p>}

      {!loading && searched && results.length === 0 && (
        <p className="text-sm text-charcoal/50">No products matched &quot;{query}&quot;.</p>
      )}

      <div className="grid grid-cols-2 gap-3">
        {results.map((p) => (
          <ProductCard key={p.id} product={p} />
        ))}
      </div>
    </main>
  );
}
