import { createClient } from "@/lib/supabase/server";
import { redirect } from "next/navigation";
import ProductCard from "@/components/ProductCard";

export default async function WishlistPage() {
  const supabase = createClient();
  const { data: { user } } = await supabase.auth.getUser();
  if (!user) redirect("/login?redirect=/wishlist");

  const { data: items } = await supabase
    .from("wishlist_items")
    .select("products(*, product_media(*), product_variants(*))")
    .eq("customer_id", user.id);

  return (
    <main className="p-4">
      <h1 className="text-base font-medium mb-4">Wishlist ({items?.length ?? 0})</h1>
      <div className="grid grid-cols-2 gap-3">
        {(items ?? []).map((i: any) => (
          <ProductCard key={i.products.id} product={i.products} />
        ))}
      </div>
      {(!items || items.length === 0) && <p className="text-sm text-charcoal/50">Nothing saved yet.</p>}
    </main>
  );
}
