"use client";

import { Suspense } from "react";

import { useState } from "react";
import { useRouter, useSearchParams } from "next/navigation";
import { createClient } from "@/lib/supabase/client";
import Link from "next/link";

function LoginPageInner() {
  const router = useRouter();
  const params = useSearchParams();
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [error, setError] = useState("");
  const [loading, setLoading] = useState(false);

  async function handleLogin(e: React.FormEvent) {
    e.preventDefault();
    setLoading(true);
    setError("");
    const supabase = createClient();
    const { error } = await supabase.auth.signInWithPassword({ email, password });
    setLoading(false);
    if (error) return setError(error.message);
    router.push(params.get("redirect") ?? "/");
  }

  return (
    <main className="p-4">
      <h1 className="font-display text-xl mb-4">Log in</h1>
      <form onSubmit={handleLogin} className="flex flex-col gap-3">
        <input type="email" required placeholder="Email" value={email} onChange={(e) => setEmail(e.target.value)}
          className="border border-charcoal/25 rounded-card px-3 py-2.5 text-sm" />
        <input type="password" required placeholder="Password" value={password} onChange={(e) => setPassword(e.target.value)}
          className="border border-charcoal/25 rounded-card px-3 py-2.5 text-sm" />
        {error && <p className="text-xs text-red-600">{error}</p>}
        <button type="submit" disabled={loading} className="btn-primary mt-1">
          {loading ? "Logging in…" : "Log in"}
        </button>
      </form>
      <p className="text-sm text-charcoal/60 mt-4">
        New here? <Link href="/signup" className="text-rust-600">Create an account</Link>
      </p>
    </main>
  );
}

export default function LoginPage() {
  return (
    <Suspense fallback={<main className="p-4 text-sm text-charcoal/50">Loading…</main>}>
      <LoginPageInner />
    </Suspense>
  );
}
