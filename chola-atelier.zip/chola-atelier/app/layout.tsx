import type { Metadata } from "next";
import "./globals.css";
import BottomNav from "@/components/BottomNav";
import Header from "@/components/Header";

export const metadata: Metadata = {
  title: "Chola Atelier",
  description: "Premium Indian fashion, jewellery and lifestyle — mobile-first store",
};

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="en">
      <body className="font-sans">
        <div className="max-w-md mx-auto min-h-screen pb-16 bg-cream">
          <Header />
          {children}
        </div>
        <BottomNav />
      </body>
    </html>
  );
}
