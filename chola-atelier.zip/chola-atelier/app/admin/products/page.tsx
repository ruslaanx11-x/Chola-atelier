import { createClient } from "@/lib/supabase/server";
import Link from "next/link";

export default async function AdminProductsPage() {
  const supabase = createClient();
  const { data: products } = await supabase
    .from("products")
    .select("id, name, price, sale_price, is_featured, product_variants(stock)")
    .order("created_at", { ascending: false });

  return (
    <div>
      <div className="flex justify-between items-center mb-4">
        <h1 className="text-lg font-medium">Products</h1>
        <Link href="/admin/products/new" className="btn-primary w-auto px-4">+ Add product</Link>
      </div>

      <div className="border border-charcoal/10 rounded-card overflow-hidden">
        {(products ?? []).map((p: any) => {
          const totalStock = p.product_variants?.reduce((s: number, v: any) => s + v.stock, 0) ?? 0;
          return (
            <div
              key={p.id}
              className="flex justify-between items-center px-4 py-3 border-b border-charcoal/10 last:border-0"
            >
              <div>
                <p className="text-sm">{p.name}</p>
                <p className="text-xs text-charcoal/50">Stock: {totalStock}</p>
              </div>
              <p className="text-sm font-medium">₹{(p.sale_price ?? p.price).toLocaleString("en-IN")}</p>
            </div>
          );
        })}
        {(!products || products.length === 0) && (
          <p className="p-4 text-sm text-charcoal/50">No products yet.</p>
        )}
      </div>
    </div>
  );
}
