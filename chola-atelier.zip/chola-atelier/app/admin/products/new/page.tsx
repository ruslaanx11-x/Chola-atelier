"use client";

import { useState } from "react";
import { useRouter } from "next/navigation";
import { createClient } from "@/lib/supabase/client";

export default function NewProductPage() {
  const router = useRouter();
  const [name, setName] = useState("");
  const [description, setDescription] = useState("");
  const [price, setPrice] = useState("");
  const [salePrice, setSalePrice] = useState("");
  const [colour, setColour] = useState("");
  const [colourHex, setColourHex] = useState("#993C1D");
  const [size, setSize] = useState("");
  const [stock, setStock] = useState("");
  const [files, setFiles] = useState<FileList | null>(null);
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState("");

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    setSaving(true);
    setError("");
    const supabase = createClient();

    try {
      const slug = name.toLowerCase().trim().replace(/[^a-z0-9]+/g, "-").replace(/(^-|-$)/g, "");

      const { data: product, error: pErr } = await supabase
        .from("products")
        .insert({ name, slug, description, price: Number(price), sale_price: salePrice ? Number(salePrice) : null })
        .select()
        .single();
      if (pErr) throw pErr;

      // First variant — add more from the product edit page after creating
      const sku = `${slug.slice(0, 6).toUpperCase()}-${colour.slice(0, 3).toUpperCase()}-${size}`;
      await supabase.from("product_variants").insert({
        product_id: product.id, colour, colour_hex: colourHex, size, sku, stock: Number(stock),
      });

      // Upload images/video to Supabase Storage bucket "product-media" (create this bucket once, set to public)
      if (files) {
        for (let i = 0; i < files.length; i++) {
          const file = files[i];
          const path = `${product.id}/${Date.now()}-${file.name}`;
          const { error: upErr } = await supabase.storage.from("product-media").upload(path, file);
          if (upErr) continue;
          const { data: urlData } = supabase.storage.from("product-media").getPublicUrl(path);
          await supabase.from("product_media").insert({
            product_id: product.id,
            media_type: file.type.startsWith("video") ? "video" : "image",
            url: urlData.publicUrl,
            sort_order: i,
          });
        }
      }

      router.push("/admin/products");
    } catch (err: any) {
      setError(err.message ?? "Something went wrong");
    } finally {
      setSaving(false);
    }
  }

  return (
    <div>
      <h1 className="text-lg font-medium mb-4">Add product</h1>
      <form onSubmit={handleSubmit} className="flex flex-col gap-3 max-w-md">
        <input required placeholder="Product name" value={name} onChange={(e) => setName(e.target.value)} className="border border-charcoal/25 rounded-card px-3 py-2.5 text-sm" />
        <textarea placeholder="Description" value={description} onChange={(e) => setDescription(e.target.value)} className="border border-charcoal/25 rounded-card px-3 py-2.5 text-sm" rows={3} />

        <div className="flex gap-3">
          <input required type="number" placeholder="Price (₹)" value={price} onChange={(e) => setPrice(e.target.value)} className="border border-charcoal/25 rounded-card px-3 py-2.5 text-sm flex-1" />
          <input type="number" placeholder="Sale price (₹, optional)" value={salePrice} onChange={(e) => setSalePrice(e.target.value)} className="border border-charcoal/25 rounded-card px-3 py-2.5 text-sm flex-1" />
        </div>

        <p className="text-xs text-charcoal/50 mt-2">First variant (add more later from the product page)</p>
        <div className="flex gap-3">
          <input required placeholder="Colour name (e.g. Rust)" value={colour} onChange={(e) => setColour(e.target.value)} className="border border-charcoal/25 rounded-card px-3 py-2.5 text-sm flex-1" />
          <input type="color" value={colourHex} onChange={(e) => setColourHex(e.target.value)} className="w-11 rounded-card border border-charcoal/25" />
        </div>
        <div className="flex gap-3">
          <input required placeholder="Size (e.g. M)" value={size} onChange={(e) => setSize(e.target.value)} className="border border-charcoal/25 rounded-card px-3 py-2.5 text-sm flex-1" />
          <input required type="number" placeholder="Stock" value={stock} onChange={(e) => setStock(e.target.value)} className="border border-charcoal/25 rounded-card px-3 py-2.5 text-sm flex-1" />
        </div>

        <label className="text-xs text-charcoal/50 mt-2">Images and video clip (5–10 images + optional video)</label>
        <input type="file" multiple accept="image/*,video/*" onChange={(e) => setFiles(e.target.files)} className="text-sm" />

        {error && <p className="text-xs text-red-600">{error}</p>}
        <button type="submit" disabled={saving} className="btn-primary mt-2">
          {saving ? "Saving…" : "Save product"}
        </button>
      </form>
    </div>
  );
}
