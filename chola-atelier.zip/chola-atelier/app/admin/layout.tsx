import { createClient } from "@/lib/supabase/server";
import { redirect } from "next/navigation";
import Link from "next/link";

export default async function AdminLayout({ children }: { children: React.ReactNode }) {
  const supabase = createClient();
  const { data: { user } } = await supabase.auth.getUser();
  if (!user) redirect("/login?redirect=/admin");

  const { data: customer } = await supabase
    .from("customers")
    .select("is_admin")
    .eq("id", user!.id)
    .single();

  if (!customer?.is_admin) redirect("/");

  return (
    <div className="max-w-3xl mx-auto p-4">
      <div className="flex gap-4 mb-6 text-sm border-b border-charcoal/10 pb-3">
        <Link href="/admin/products" className="font-medium">Products</Link>
        <span className="text-charcoal/30" title="Coming soon">Orders</span>
        <span className="text-charcoal/30" title="Coming soon">Coupons</span>
      </div>
      {children}
    </div>
  );
}
