import { createClient } from "@/lib/supabase/server";
import { notFound } from "next/navigation";
import ProductGallery from "@/components/ProductGallery";
import ProductActions from "@/components/ProductActions";
import WishlistButton from "@/components/WishlistButton";

export default async function ProductPage({ params }: { params: { slug: string } }) {
  const supabase = createClient();

  const { data: product } = await supabase
    .from("products")
    .select("*, product_media(*), product_variants(*)")
    .eq("slug", params.slug)
    .single();

  if (!product) return notFound();

  const media = (product.product_media ?? []).sort((a: any, b: any) => a.sort_order - b.sort_order);
  const variants = product.product_variants ?? [];
  const colours = [...new Map(variants.map((v: any) => [v.colour, v])).values()];
  const sizes = [...new Set(variants.map((v: any) => v.size))];

  const discount =
    product.sale_price && product.price > product.sale_price
      ? Math.round(((product.price - product.sale_price) / product.price) * 100)
      : 0;

  return (
    <main>
      <div className="relative">
        <ProductGallery media={media} />
        <div className="absolute top-3 right-3 bg-cream/90 rounded-full p-1.5">
          <WishlistButton productId={product.id} />
        </div>
      </div>

      <div className="p-4">
        <p className="text-xs text-charcoal/50 mb-1">Chola Atelier</p>
        <h1 className="font-display text-xl mb-1.5">{product.name}</h1>
        <div className="flex items-baseline gap-2 mb-3">
          <span className="text-lg font-medium">
            ₹{(product.sale_price ?? product.price).toLocaleString("en-IN")}
          </span>
          {product.sale_price && (
            <span className="text-sm text-charcoal/40 line-through">
              ₹{product.price.toLocaleString("en-IN")}
            </span>
          )}
          {discount > 0 && <span className="text-xs text-rust-600">{discount}% off</span>}
        </div>

        <div className="flex items-center gap-2 bg-green-50 rounded-card px-3 py-2 mb-4 text-xs text-green-700">
          Use code <span className="font-medium">CHOLA200</span> · extra ₹200 off
        </div>

        <ProductActions product={product} colours={colours as any} sizes={sizes as any} variants={variants as any} />

        <div className="mt-6 pt-4 border-t border-charcoal/10">
          <p className="text-sm text-charcoal/60 mb-1">Description</p>
          <p className="text-sm leading-relaxed">{product.description}</p>
        </div>
      </div>
    </main>
  );
}
